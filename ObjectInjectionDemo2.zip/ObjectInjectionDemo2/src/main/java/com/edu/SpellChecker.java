package com.edu;

public class SpellChecker {

	

	

	public void Function() {
		// TODO Auto-generated method stub
		System.out.println("SpellCheck is enabled");
		
	}
}