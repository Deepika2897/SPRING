package com.edu;

public class Book {
private int bid;
private String bname;
private int bprice;
public int getBid() {
	return bid;
}
public void setBid(int bid) {
	this.bid = bid;
}
public String getBname() {
	return bname;
}
public void setBname(String bname) {
	this.bname = bname;
}
public int getBprice() {
	return bprice;
}
public void setBprice(int bprice) {
	this.bprice = bprice;
}
public void display()
{
	System.out.println("book id="+bid);
	System.out.println("book name="+bname);
	System.out.println("book price="+bprice);
}
}
