package com.edu;

public class TextEditor {
private SpellChecker spellchecker;


public TextEditor(SpellChecker spellchecker) {
	super();
	this.spellchecker = spellchecker;
}


public void texteditorfunc()
{
	if(spellchecker!=null)
	{
		spellchecker.Function();
	}
	else
	{
		System.out.println("Disabled");
	}
}}
