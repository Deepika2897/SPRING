package com.edu;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.Statement;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class Updateoperation
 */
@WebServlet("/UpdateOperation")
public class UpdateOperation extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public UpdateOperation() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		//response.getWriter().append("Served at: ").append(request.getContextPath());
		PrintWriter out=response.getWriter();
		response.setContentType("text/html");
		int id=Integer.parseInt(request.getParameter("sid"));
		String name=request.getParameter("sname");
		
		try
		{
			Connection con=DbConnect.getconnection();
			Statement st=con.createStatement();
			String sel="select *from student where sid="+id;
			ResultSet rst=st.executeQuery(sel);
			if(rst.next())
			{
			
			String upd="update student set sname='"+name+"' where sid="+id;
			int i=st.executeUpdate(upd);
			if(i>0)
			{
				out.println("updated successfully");
			}
			else
			{
				out.println(" Not updated");
			}
		}
			else
			{
				out.println("Id not exits");
			}
		}
			
			catch(Exception e)
		{
			e.printStackTrace();
		}
	
	}}
