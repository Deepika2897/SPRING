package com.edu;

public class Heart {

	
	public void pump() {
		
		System.out.println("Heart is pumping");
		System.out.println("Heart is alive");
		
	}

}
