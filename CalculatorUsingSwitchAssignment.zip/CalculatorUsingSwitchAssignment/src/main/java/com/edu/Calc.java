package com.edu;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class Calc
 */
@WebServlet("/Calc")
public class Calc extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public Calc() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		//response.getWriter().append("Served at: ").append(request.getContextPath());
		int number1=Integer.parseInt(request.getParameter("num1"));
		int number2=Integer.parseInt(request.getParameter("num2"));
		int ans;
		PrintWriter out=response.getWriter();
		String bn=request.getParameter("op");
		switch(bn)
		{
		case "Add":
			out.println("Answer= " +(number1+number2));
			break;
		case "Subtract":
			out.println("Answer= " +(number1-number2));
			break;
		case "Multiply":
			out.println("Answer= " +(number1*number2));
			break;
		case "Divide":
		case "Div":
	        if(number2==0) {
	        	out.println("Divide by zero error");
	        }
	        else {
	
	        	ans=number1/number2;
	        	out.println("Quotient of "+number1+" and "+number2+" is "+ans);
	       
	        	break;
			
	}}}}
	


