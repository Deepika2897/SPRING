package com.edu;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.Statement;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class SelectAllOperation
 */
@WebServlet("/SelectAllOperation")
public class SelectAllOperation extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public SelectAllOperation() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		//response.getWriter().append("Served at: ").append(request.getContextPath());
		 PrintWriter out=response.getWriter();
		    response.setContentType("text/html");
			
				try {
					Connection conn=DbConnect.getconnection();
					Statement st=conn.createStatement();
				    String selall="select * from student";
					ResultSet rst=st.executeQuery(selall);
					
					out.println("<!DOCTYPE html>");
					out.println("<head><title>Student Details </title></head>");
					out.println("<body>");
					out.println("<table border='1'>");
					out.println("<tr><th> SID </th><th> SNAME </th><th> SAGE </th><th> SFEES </th><tr>");
					
					while(rst.next())
					{
						
						out.println("<tr><td>"+rst.getInt(1)+"</td>"+"<td>"+rst.getString(2)+"</td>"+"<td>"+rst.getInt(3)+"</td>"+"<td>"+rst.getFloat(4)+"</td></tr>");
					
					}
					out.println("</table>");
					out.println("</body></html>");
					
					
				}catch(Exception e)
				{
					e.printStackTrace();
					
				}
			
		
		
		
		}


	
	
	
	
	}
