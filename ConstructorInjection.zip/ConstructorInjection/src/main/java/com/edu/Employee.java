package com.edu;

public class Employee {
	private int empid;
	private String empname;
	private double empsal;
	public Employee(int empid, String empname,Double empsal) {
		super();
		this.empid = empid;
		this.empname = empname;
		this.empsal = empsal;
	}
	public void display()
	{
		System.out.println("employee id: " +empid);
		System.out.println("employee name: " +empname);
		System.out.println("employee salary: "+empsal);
	}
	

}
